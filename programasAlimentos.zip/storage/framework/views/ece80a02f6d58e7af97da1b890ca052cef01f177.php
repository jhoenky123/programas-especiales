<?php
    $original_local = setlocale(LC_TIME,0);
    setlocale(LC_TIME,App::getLocale());
?>
<?php echo e(!empty($value) ? ucfirst(strftime("%B, %d %G %H:%M:%S", strtotime($value))) : null); ?>

<?php
    setlocale(LC_TIME,$original_local);
?><?php /**PATH /home/wili/Escritorio/Proyectos/Laravel/ProgramasAlimentos/vendor/crocodicstudio/crudbooster/src/views/default/type_components/datetime/component_detail.blade.php ENDPATH**/ ?>