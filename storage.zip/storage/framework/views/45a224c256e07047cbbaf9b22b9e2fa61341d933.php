<div id='header<?php echo e($index); ?>' data-collapsed="<?php echo e(($form['collapsed']===false)?'false':'true'); ?>" class='header-title form-divider'>
    <h4>
        <strong><i class='<?php echo e($form['icon']?:"fa fa-check-square-o"); ?>'></i> <?php echo e($form['label']); ?></strong>
        <span class='pull-right icon'><i class='fa fa-minus-square-o'></i></span>
    </h4>
</div><?php /**PATH C:\laragon\www\programasAlimentos\vendor\crocodicstudio\crudbooster\src/views/default/type_components/header/component.blade.php ENDPATH**/ ?>